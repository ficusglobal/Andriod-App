package com.school.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import utils.AppConstants;
import utils.Constants;
import utils.Utility;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    EditText mEt_Email, mEt_Password;
    private Button mLogin;
private String mEmail,mPassword;

private RadioGroup mRadiogroup;
private String mRadioAdmin,mRadiostudent,mRadioemp,mRadionparents;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        setlayoutRef();


    }

    private void setlayoutRef() {
        mEt_Email = (EditText) findViewById(R.id.et_email);
        mEt_Password = (EditText) findViewById(R.id.et_password);
        mLogin = (Button) findViewById(R.id.login);
        mRadiogroup = (RadioGroup) findViewById(R.id.logintypeRadiogroup);
        mLogin.setOnClickListener(this);

        mRadiogroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                if (checkedId == R.id.radioadmin) {
                     mRadioAdmin="Admin";


                    //do work when radioButton1 is active
                } else  if (checkedId == R.id.radiostudent) {
                    mRadiostudent="Student";

                    //do work when radioButton2 is active

            } else  if (checkedId == R.id.radioemployee) {
                mRadioemp="Employee";

                //do work when radioButton2 is active
            } else  if (checkedId == R.id.radioparents) {
            mRadionparents="Parents";

            //do work when radioButton2 is active
        }

            }
        });

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.login:
               validation();
                break;

    }
}

    private void validation() {
        mEmail = mEt_Email.getText().toString().trim();
        mPassword = mEt_Password.getText().toString().trim();
        if (mEmail.equals("")) {

            Toast.makeText(getApplicationContext(), getString(R.string.email_error), Toast.LENGTH_SHORT).show();

        } else if (!Utility.isValidEmail(mEmail)) {

            Toast.makeText(getApplicationContext(), getString(R.string.error_invalid_email), Toast.LENGTH_SHORT).show();


        } else if (mPassword.equals("")) {
            Toast.makeText(getApplicationContext(), getString(R.string.password_error), Toast.LENGTH_SHORT).show();
        } else if (!mEmail.equals("") && !mPassword.equals("")) {
            consumeLoginAPI();

        }
    }

    private void consumeLoginAPI() {
        try {
            Utility.showProgressdialog(LoginActivity.this);
            final String loginUrl = AppConstants.BASE_URL + AppConstants.LoginAPI;
            JSONObject jsonObject = new JSONObject();
            Map<String, String> mLoginParams = new HashMap<>();

            jsonObject.put(Constants.usertype,"student");
            jsonObject.put(Constants.username,mEmail);
            jsonObject.put(Constants.password,mPassword);
            Map<String, String> mHeaderParams = new HashMap<>();
            mHeaderParams.put("Content-Type", "application/json");

            volleySubmitULoginAPI(this, loginUrl, jsonObject, mLoginParams,mHeaderParams,0);
            // } else {
            //   utilityDialog.displayDialogToShowMessage("Please connect your device with internet.", LoginCaregiverActivity.this);
            // }
            // }
        } catch (Exception e) {
            e.printStackTrace();
            //FlurryAgent.logEvent(e + "");
        }
    }


    public void volleySubmitULoginAPI(final Context context, final String url,
                                      final JSONObject jsonObject, final Map<String, String> map,final Map<String, String> mHeaderParams,  final int type) {


        JsonObjectRequest jsonobj = new JsonObjectRequest(Request.Method.POST, url, jsonObject,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            Utility.dismissProgressdialogUtility(context);
                            Log.e("token", "Login" + response);
                           String responsenew = (response.toString());

                            JSONObject json = new JSONObject(responsenew);

                            JSONObject jsonObject1= json.getJSONObject("payload");
                            String obj = jsonObject1.getString("token");

                            System.out.println("get token"+obj);

                            String obj1 = json.getString("message");

                            Toast.makeText(LoginActivity.this, obj1, Toast.LENGTH_SHORT).show();

                            System.out.println("get response" + responsenew);

                            Intent intent=new Intent(LoginActivity.this,ProfileActivity.class);
                            startActivity(intent);
                           // showDialogsubmitobservation(context);


                        } catch (Exception e) {

                        }
                        //  JSONArray jsonArray = new JSONArray(response);

                           /* for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jresponse =
                                        jsonArray.getJSONObject(i);
                                String statuscode =
                                        jresponse.getString("StatusCode");
                              String  message =
                                        jresponse.getString("Message");



                                if (statuscode.equals("200")) {

                                    // Toast.makeText(context, message, Toast.LENGTH_SHORT).show();


                                    showDialogsubmitobservation(context);
                                    //  Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
                                }
                          */  //}

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context, "Status Code  " + error, Toast.LENGTH_SHORT).show();
                        //callback.onErrorResponse(error);
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                return map;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return mHeaderParams;
            }

        };

        int socketTimeout = 60000; // 30 seconds. You can change it
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        jsonobj.setRetryPolicy(policy);
        // Adding request to request queue
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(jsonobj);

}
    }