package utils;

/**
 * Created by sonud on 09/10/2018.
 */

public class AppConstants {



    public static String BASE_URL = "http://ficusglobal.com/FicusSchool/api";

    ///////Supplier API
    public static String LoginAPI = "/Login/login_process";



}
