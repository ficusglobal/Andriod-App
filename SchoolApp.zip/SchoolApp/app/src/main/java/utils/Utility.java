package utils;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.util.Patterns;

import androidx.annotation.Nullable;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by sonu on 09/10/2018.
 */

public class Utility {

    private String installationDate;
    public boolean islocked = false;
    private Dialog customDialog;
    private int noofDays;
    private String trialDays;
    private String message;

    public static int tryInt(String str) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static ProgressDialog progressDialog = null;
    private static ProgressDialog mProgressDialog;


    public Utility() {

    }



    public static Boolean checkForNull(String val) {
        if (val == "null") {
            return true;
        }
        return false;
    }

    public static boolean isEmpty(@Nullable CharSequence str) {
        if (str == null || str.length() == 0)
            return true;
        else
            return false;
    }


    public static final boolean isValidMobilenew(CharSequence target) {
        if (target.length() != 10) {
            return false;
        } else {
            return Patterns.PHONE.matcher(target).matches();
        }
    }

    public static final boolean isValidAadharNumbernew(CharSequence target) {
        if (target.length() != 12) {
            return false;
        } else {
            return Patterns.PHONE.matcher(target).matches();
        }
    }
    public static final boolean isValidIfsccode(CharSequence target) {
        if (target.length() != 11) {
            return false;
        } else {
            return Patterns.PHONE.matcher(target).matches();
        }
    }



    public static final boolean isValidAadharGst(CharSequence target) {
        if (target.length() != 15) {
            return false;
        } else {
            return Patterns.PHONE.matcher(target).matches();
        }
    }


    public static boolean isValidEmail (CharSequence target){
        if (target == null) {
            return false;
        } else {
            return Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }




    /*
     * Created by sonu oct 2018
     * @description below this method is used to show progress dialog
     * */
    public static void showProgressdialog(Activity ctx) {
        try {
            if (mProgressDialog == null) {
                mProgressDialog = new ProgressDialog(ctx);
                mProgressDialog.setMessage("Loading ...");
                mProgressDialog.setIndeterminate(true);
                mProgressDialog.setCancelable(false);
                mProgressDialog.show();
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /*
     * created by sonu oct 2018
     * @description below method is use to dismiss the dialog
     * */

    public static void dismissProgressdialog(Activity ctx) {
        try {
            if (mProgressDialog == null) {
                return;
            } else {
                mProgressDialog.dismiss();
                mProgressDialog = null;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }


    public static void dismissProgressdialogUtility(Context ctx) {
        try {
            if (mProgressDialog == null) {
                return;
            } else {
                mProgressDialog.dismiss();
                mProgressDialog = null;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }


    /**
     * @return boolean
     * @author Chetu
     * @date March 17, 2017
     * @argument
     * @description To check internet connection.
     */


    public static boolean isEmailValid(String email) {

        String regExpn = "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";
        CharSequence inputStr = email;
        Pattern pattern = Pattern.compile(regExpn, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches())
            return true;
        else
            return false;
    }


}