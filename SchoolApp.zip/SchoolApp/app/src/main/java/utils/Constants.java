package utils;

/**
 * Created by sonud on 09/10/2018.
 */

public class Constants {


    public static final String username = "username";
    public static final String password = "password";
    public static final String usertype = "usertype";




}
